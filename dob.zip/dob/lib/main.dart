import 'package:dob/bloc/simple_bloc_delegate.dart';
import 'package:dob/data/AuthRepository.dart';
import 'package:dob/pages/homescreen.dart';
import 'package:dob/pages/login/loginscreen.dart';
import 'package:dob/pages/splashscreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/authentication_bloc.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  BlocSupervisor.delegate = SimpleBlocDelegate();
  final AuthRepository authRepository = AuthRepository();

  runApp(
    BlocProvider<AuthenticationBloc>(
      create: (context) =>
          AuthenticationBloc(authRepository: authRepository)..add(AppStarted()),
      child: MyApp(
        authRepository: authRepository,
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  final AuthRepository _authRepository;
  MyApp({Key key, @required AuthRepository authRepository})
      : assert(authRepository != null),
        _authRepository = authRepository,
        super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BlocBuilder<AuthenticationBloc,AuthenticationState>(
        builder: (context, state) {
          if (state is Uninitialized) {
            return SplashScreen();
          }
           if (state is UnAuthenticated) {
            return LoginScreen(authRepository: _authRepository);
          }
          else if(state is Authenticated){
            return HomeScreen(name: state.user,);
          }
        },
      ),
    );
  }
}
